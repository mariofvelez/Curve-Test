package test;

import java.awt.Graphics2D;

public class Vec2d {
	float x;
	float y;
	
	public Vec2d(float x, float y)
	{
		this.x = x;
		this.y = y;
	}
	public static Vec2d lerp(Vec2d a, Vec2d b, float dist)
	{
		Vec2d dir = subtract(b, a);
		Vec2d lerped = Vec2d.add(a, Vec2d.mult(dir, dist));
		return lerped;
	}
	public static Vec2d add(Vec2d a, Vec2d b)
	{
		return new Vec2d(a.x + b.x, a.y + b.y);
	}
	public static Vec2d subtract(Vec2d a, Vec2d b)
	{
		return new Vec2d(a.x - b.x, a.y - b.y);
	}
	public static Vec2d mult(Vec2d a, float b)
	{
		return new Vec2d(a.x*b, a.y*b);
	}
	public float length()
	{
		return (float) Math.sqrt(x*x + y*y);
	}
	public void draw(Graphics2D g2)
	{
		g2.fillOval((int)x-2, (int)y-2, 4, 4);
	}
	
}
