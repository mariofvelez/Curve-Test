package test;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;

public class SliderPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6319680352055445882L;
	public static JSlider lerp_slider;
	public static JLabel label;
	
	public static JSlider point_slider;
	public static JLabel label2;
	
	public SliderPanel()
	{
		setLayout(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		
		label = new JLabel("Interpolations");
		add(label, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		
		lerp_slider = new JSlider();
		lerp_slider.setMaximum(20);
		lerp_slider.setMinimum(2);
		add(lerp_slider, gc);
		
		gc.gridx = 0;
		gc.gridy = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		
		label2 = new JLabel("Find Point");
		add(label2, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		
		point_slider = new JSlider();
		point_slider.setMaximum(1000);
		point_slider.setMinimum(0);
		point_slider.setValue(0);
		add(point_slider, gc);
		
		setBorder(BorderFactory.createEtchedBorder());
	}

}
