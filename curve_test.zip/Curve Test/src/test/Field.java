package test;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferStrategy;
import java.util.ArrayList;

import java.lang.System;

/**
 * 
 * @author Mario Velez
 *
 */
public class Field extends Canvas
		implements KeyListener, MouseMotionListener, MouseListener, MouseWheelListener,
				   Runnable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -796167392411348854L;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	private Graphics bufferGraphics; // graphics for backbuffer
	private BufferStrategy bufferStrategy;
	
	public static int mousex = 0; // mouse values
	public static int mousey = 0;

	public static ArrayList<Integer> keysDown; // holds all the keys being held down
	boolean leftClick;

	private Thread thread;

	private boolean running;
	private int refreshTime;
	
	public static int[] anchor = new  int[2];
	public static boolean dragging;
	
	Vec2d[] points;
	
	public Field(Dimension size) throws Exception {
		this.setPreferredSize(size);
		this.addKeyListener(this);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addMouseWheelListener(this);

		this.thread = new Thread(this);
		running = true;
		refreshTime = (int) (1f/50 * 1000);

		keysDown = new ArrayList<Integer>();
		
		points = new Vec2d[4];
		points[0] = new Vec2d(100, 300);
		points[1] = new Vec2d(200, 200);
		points[2] = new Vec2d(300, 300);
		points[3] = new Vec2d(400, 200);
		
	}

	public void paint(Graphics g) {


		if (bufferStrategy == null) {
			this.createBufferStrategy(2);
			bufferStrategy = this.getBufferStrategy();
			bufferGraphics = bufferStrategy.getDrawGraphics();

			this.thread.start();
		}
	}
	@Override
	public void run() {
		// what runs when editor is running
		
		while (running) {
			long t1 = System.currentTimeMillis();
			
			DoLogic();
			Draw();

			DrawBackbufferToScreen();

			Thread.currentThread();
			try {
				Thread.sleep(refreshTime);
			} catch (Exception e) {
				e.printStackTrace();
			}
			long t2 = System.currentTimeMillis();
			
			if(t2 - t1 > 16)
			{
				if(refreshTime > 0)
					refreshTime --;
			}
			else
				refreshTime ++;
		}
	}

	public void DrawBackbufferToScreen() {
		bufferStrategy.show();

		Toolkit.getDefaultToolkit().sync();
	}
	private Vec2d findCurve(float dist)
	{
		Vec2d[] layer1 = {
				Vec2d.lerp(points[0], points[1], dist),
				Vec2d.lerp(points[1], points[2], dist),
				Vec2d.lerp(points[2], points[3], dist)
		};
		Vec2d[] layer2 = {
				Vec2d.lerp(layer1[0], layer1[1], dist),
				Vec2d.lerp(layer1[1], layer1[2], dist)
		};
		Vec2d layer3 = Vec2d.lerp(layer2[0], layer2[1], dist);
		return layer3;
	}
	public void DoLogic() {
		
	}
	public int lerps = 10;
	public void Draw() // titleScreen
	{
		// clears the backbuffer
		bufferGraphics = bufferStrategy.getDrawGraphics();
		try {
			bufferGraphics.clearRect(0, 0, this.getSize().width, this.getSize().height);
			// where everything will be drawn to the backbuffer
			Graphics2D g2 = (Graphics2D) bufferGraphics;
			g2.setColor(Color.LIGHT_GRAY);
			g2.drawLine((int)points[0].x, (int)points[0].y, (int)points[1].x, (int)points[1].y);
			g2.drawLine((int)points[2].x, (int)points[2].y, (int)points[3].x, (int)points[3].y);
			g2.setColor(Color.BLACK);
			for (int i = 0; i < points.length; i++)
				points[i].draw(g2);
			lerps = SliderPanel.lerp_slider.getValue();
			SliderPanel.label.setText("Interpolations (" + lerps + ")");
			Vec2d[] lerps = new Vec2d[this.lerps];
			g2.setColor(Color.BLUE);
			for(int i = 0; i < lerps.length; i++)
			{
				Vec2d vec = findCurve((float)i / (float)lerps.length);
				lerps[i] = vec;
				
				if(i > 0)
					g2.drawLine((int)lerps[i].x, (int)lerps[i].y, (int)lerps[i-1].x, (int)lerps[i-1].y);
			}
			g2.drawLine((int)lerps[lerps.length-1].x, (int)lerps[lerps.length-1].y, (int)points[3].x, (int)points[3].y);
			
			g2.setColor(Color.BLACK);
			float point_lerp = SliderPanel.point_slider.getValue() / 1000f;
			Vec2d point = findCurve(point_lerp);
			
			point.draw(g2);
			
			g2.drawString("Drag the points", 10, 20);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			bufferGraphics.dispose();
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!keysDown.contains(e.getKeyCode()) && e.getKeyCode() != 86)
			keysDown.add(new Integer(e.getKeyCode()));
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		keysDown.remove(new Integer(e.getKeyCode()));
		
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {

	}
	Vec2d hold = null;
	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getButton() == 1)
		{
			leftClick = true;
			Vec2d mouse = new Vec2d(mousex, mousey);
			for(int i = 0; i < points.length; i++)
			{
				if(Vec2d.subtract(points[i], mouse).length() < 15)
					hold = points[i];
			}
		}
		else if(e.getButton() == 2)
		{
			
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if(e.getButton() == 1)
		{
			leftClick = false;
			hold = null;
		}
		if(e.getButton() == 2)
			dragging = false;
	}
	int p_x = 0;
	int p_y = 0;
	@Override
	public void mouseDragged(MouseEvent e) {
		if(leftClick)
			leftClick = true;
		p_x = mousex;
		p_y = mousey;
		mousex = e.getX();
		mousey = e.getY();
		if(hold != null)
		{
			hold.x += mousex-p_x;
			hold.y += mousey-p_y;
		}
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		mousex = e.getX();
		mousey = e.getY();
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		
	}

}
